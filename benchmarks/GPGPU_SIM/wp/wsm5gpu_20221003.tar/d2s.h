
delt_s	=	delt
g_s	=	g
rd_s	=	rd
rv_s	=	rv
t0c_s	=	t0c
den0_s	=	den0
cpd_s	=	cpd
cpv_s	=	cpv
ep1_s	=	ep1
ep2_s	=	ep2
qmin_s	=	qmin
XLS_s	=	XLS
XLV0_s	=	XLV0
XLF0_s	=	XLF0
cliq_s	=	cliq
cice_s	=	cice
psat_s	=	psat
denr_s	=	denr

th_s(its:ite,kts:kte,jts:jte)     =       th(its:ite,kts:kte,jts:jte)    
pii_s(its:ite,kts:kte,jts:jte)    =       pii(its:ite,kts:kte,jts:jte)   
q_s(its:ite,kts:kte,jts:jte)      =       q(its:ite,kts:kte,jts:jte)     
qc_s(its:ite,kts:kte,jts:jte)     =       qc(its:ite,kts:kte,jts:jte)    
qi_s(its:ite,kts:kte,jts:jte)     =       qi(its:ite,kts:kte,jts:jte)    
qr_s(its:ite,kts:kte,jts:jte)     =       qr(its:ite,kts:kte,jts:jte)    
qs_s(its:ite,kts:kte,jts:jte)     =       qs(its:ite,kts:kte,jts:jte)    
den_s(its:ite,kts:kte,jts:jte)    =       den(its:ite,kts:kte,jts:jte)   
p_s(its:ite,kts:kte,jts:jte)      =       p(its:ite,kts:kte,jts:jte)     
delz_s(its:ite,kts:kte,jts:jte)   =       delz(its:ite,kts:kte,jts:jte)  
rain_s(its:ite,jts:jte)           =       rain(its:ite,jts:jte)
rainncv_s(its:ite,jts:jte)        =       rainncv(its:ite,jts:jte)
sr_s(its:ite,jts:jte)             =       sr(its:ite,jts:jte)
snow_s(its:ite,jts:jte)           =       snow(its:ite,jts:jte)
snowncv_s(its:ite,jts:jte)        =       snowncv(its:ite,jts:jte)

